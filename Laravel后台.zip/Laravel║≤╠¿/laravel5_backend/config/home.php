<?php

return [

    //blog 默认缓存多久
    'cache_control' => 120,

];
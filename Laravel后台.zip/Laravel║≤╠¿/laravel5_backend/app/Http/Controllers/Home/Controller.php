<?php namespace App\Http\Controllers\Home;

use Illuminate\Routing\Controller as BaseController;

/**
 * 父控制类类
 *
 * @author jiang <mylampblog@163.com>
 */
abstract class Controller extends BaseController {


}

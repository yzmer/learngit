<?php

namespace App\Widget\Home;

/**
 * 小组件
 *
 * @author jiang <mylampblog@163.com>
 */
Abstract class AbstractBase
{
    

}
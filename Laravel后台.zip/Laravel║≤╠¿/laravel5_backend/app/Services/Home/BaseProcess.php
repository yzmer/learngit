<?php

/**
 * 业务基类
 *
 * @author jiang
 */

namespace App\Services\Home;

use App\Services\Home\AbstractService;

class BaseProcess extends AbstractService
{
    
    
}

<?php

/**
 * 表单验证基类
 *
 * @author jiang
 */

namespace App\Services\Home;

use App\Services\Home\AbstractService;

class BaseValidate extends AbstractService
{
    
    
}

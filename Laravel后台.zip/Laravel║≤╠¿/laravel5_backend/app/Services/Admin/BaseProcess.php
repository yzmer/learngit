<?php

/**
 * 业务基类
 *
 * @author jiang
 */

namespace App\Services\Admin;

use App\Services\Admin\AbstractService;

class BaseProcess extends AbstractService
{
    
    
}

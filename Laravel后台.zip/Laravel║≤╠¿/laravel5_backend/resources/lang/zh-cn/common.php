<?php

return array(
    'info_incomplete' => '信息填写不完整！',
    'action_success' => '操作成功！',
    'action_error' => '操作失败！',
    'illegal_operation' => '非法操作！',
    'choose_checked' => '请先选择所要操作的选项！',
    'sys_account' => '系统帐号无法删除！',
    'account_level_deny' => '帐号等级不足进行进行此操作！',
);
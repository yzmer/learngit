<?php

return array(
    //用户增加
    'user_not_found' => '没有这个用户！',
    'account_exists' => '用户名已经存在！',
    'account_name_empty' => '用户名必须输入！',
    'password_empty' => '用户密码必须输入！',
    'realname_empty' => '真实姓名必须输入！',
    'group_empty' => '请先选择用户组！',
    'mobile_empty' => '手机号不能为空！',
    'new_password_empty' => '请输入新密码！',
    'newPasswordRepeat' => '请再次输入新密码！',
    'password_comfirm' => '两次输入密码不一致！',
    'old_password_wrong' => '旧密码错误！',
);
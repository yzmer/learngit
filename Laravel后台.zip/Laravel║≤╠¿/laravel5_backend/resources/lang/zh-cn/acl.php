<?php

return array(
    //权限菜单增加
    'acl_not_found' => '没有这个功能菜单！',
    'acl_name_empty' => '功能名字为空！',
    'acl_module_empty' => '模块名为空！',
    'acl_class_empty' => '类名为空！',
    'acl_pid_empty' => '没有选择父级功能！',
    'acl_action_empty' => '函数名为空！',
    'acl_exists' => '该功能已经存在！',
    'acl_has_son' => '该功能包括子功能，请先删除或移动到别的组！',
);
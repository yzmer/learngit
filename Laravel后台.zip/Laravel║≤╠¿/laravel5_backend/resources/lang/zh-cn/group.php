<?php

return array(
    //增加用户组
    'group_not_found' => '没有这个用户组！',
    'group_name_empty' => '用户组名不能为空！',
    'group_level_empty' => '用户组等级不能为空！',
);
<?php

return array(
    'workflow_name_empty' => '工作流名字不能为空',
    'workflow_description_empty' => '工作流备注不能为空',
    'workflow_not_found' => '查无信息',
    'workflow_step_level_empty' => '工作流步骤所属步骤还没有选择',
    'workflow_id_empty' => '工作流数据异常，请刷新页面重试',
    'step_not_found' => '查无信息',
    'relation_user_empty' => '关联用户没有选择',
    'code_exists' => '调用代码已存在',
    'workflow_code_empty' => '调用代码没有填写',
    'workflow_type_empty' => '工作流类型没有填写',
);
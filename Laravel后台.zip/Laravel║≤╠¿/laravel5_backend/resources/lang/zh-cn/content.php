<?php

return array(
    'title_empty' => '文章标题不能为空。',
    'summary_empty' => '文章简介不能为空。',
    'tags_empty' => '文章标签不能为空。',
    'classify_empty' => '文章分类不能为空。',
    'content_empty' => '文章内容不能为空。',
    'status_empty' => '请选择文章是否发布。',
    'not_found' => '没有此文章。',
);
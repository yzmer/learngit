<?php

return array(
    'action_error' => '失败，请重试。',
    'comment_object_id_empty' => '非法操作。',
    'comment_object_type_empty' => '非法操作。',
    'comment_nickname_empty' => '请输入昵称。',
    'comment_content_empty' => '请输入评论内容。',
    'reply_comment_not_exist' => '所回复的内容不存在了。',
);
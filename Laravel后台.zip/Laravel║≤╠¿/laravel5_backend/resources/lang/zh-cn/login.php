<?php

return array(
    'please_input_username' => '请输入用户名',
    'please_input_password' => '请输入密码',
    'login_sys' => '登录系统成功',
);
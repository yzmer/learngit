<?php

return array(
    'name_empty' => '请输入文章分类名。',
    'is_active_empty' => '请选择是否激活。',
    'not_found' => '信息没有找到。'
);